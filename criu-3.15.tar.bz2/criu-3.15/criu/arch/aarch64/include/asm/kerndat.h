#ifndef __CR_ASM_KERNDAT_H__
#define __CR_ASM_KERNDAT_H__

#define kdat_compatible_cr()			0
#define kdat_can_map_vdso()			0

#endif /* __CR_ASM_KERNDAT_H__ */
