#ifndef __COMPEL_PLUGIN_SHMEM_PRIV_H__
#define __COMPEL_PLUGIN_SHMEM_PRIV_H__

struct shmem_plugin_msg {
	unsigned long start;
	unsigned long len;
};

#endif /* __COMPEL_PLUGIN_SHMEM_PRIV_H__ */

