#ifndef __CR_INC_BITOPS_H__
#define __CR_INC_BITOPS_H__
#include "common/bitops.h"
#endif
