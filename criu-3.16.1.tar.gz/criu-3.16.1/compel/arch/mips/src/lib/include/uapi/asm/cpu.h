#ifndef __CR_ASM_CPU_H__
#define __CR_ASM_CPU_H__

typedef struct {
} compel_cpuinfo_t;
#endif /* __CR_ASM_CPU_H__ */
